﻿define p = Character("[player_name]")
define mod1_friendA = Character("FriendA")