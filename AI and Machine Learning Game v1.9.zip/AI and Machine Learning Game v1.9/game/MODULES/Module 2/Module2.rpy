# Intro
label module2_intro:

    call screen module2_intro

label module2_start:

    call screen module2_start

    menu module2_continue_menu:
        "Continue to simulation":
            jump module2_simulation


# -------------------------------------------------
# SIMULATION (Career Fair Scene)
# -------------------------------------------------

label module2_simulation:

    scene bg careerfair

    "After learning about AI in Dr. Cornell’s class, you begin researching it in your free time."

    "Eventually, your university hosts a career fair for tech internships."

    "You walk around until you find a booth labeled GRIN."

    p "Hello, my name is [player_name]."

    p "I’m really interested in AI, and I’d love to learn more about your company."

    show mod2_friendB normal at right

    mod2_friendB "Of course! My name is mod2_friendB."

    mod2_friendB "GRIN stands for Governance, Resilience, Integration, and Networking."

    mod2_friendB "These pillars guide how we work with AI systems."

    mod2_friendB "Do you have any experience with AI?"

    p "I’ve learned about it in class and done some research on my own."

    mod2_friendB "So no hands-on experience yet?"

    "You look down, slightly nervous."

    p "Not yet, but I’m eager to learn and gain experience."

    mod2_friendB "You remind me of myself when I started."

    mod2_friendB "We’re offering entry-level internships."

    mod2_friendB "But first, I’d like to ask you a few questions."

    mod2_friendB "I won’t tell you if you’re correct."

    mod2_friendB "Sound fair?"

    p "Yes! Thank you for the opportunity."

    jump module2_quiz



# -------------------------------------------------
# QUIZ (7 QUESTIONS)
# -------------------------------------------------

label module2_quiz:

    $ score = 0
    $ wrong_questions = []


# Q1 (Correct = 1)
    mod2_friendB "Great, let's begin. The first question is, how is AI commonly used in healthcare?"
    
    p "In healthcare, AI is used to..."

    menu:
        "AI is used for diagnosis, medical imaging, and improving patient care":
            $ score += 1
        "2.	AI is mainly used to prescribe medications independently without any input from doctors":
            $ wrong_questions.append("Q1")
        "3.	AI is used to guarantee accurate predictions of diseases once symptoms appear.":
            $ wrong_questions.append("Q1")
        "4.	AI is commonly used to provide clear instructions for older patients.":
            $ wrong_questions.append("Q1")


# Q2 (Correct = 1)
    mod2_friendB "Next question, what is one way AI helps businesses?"

    p "One way AI helps businesses is..."

    menu:
        
        "AI replaces the need for oversight in complex systems":
            $ wrong_questions.append("Q2")
        "AI is used for customer service inventory management and predicting demand":
            $ score += 1
        "AI speeds up output by increasing employee workload":
            $ wrong_questions.append("Q2")
        "AI guarantees 100% error free decision making":
            $ wrong_questions.append("Q2")


# Q3 (Correct = 1)
    mod2_friendB "Moving on, how does AI improve learning in education?"

    p "It improves education by..."

    menu:
        
        "AI standardizes education so every student learns the same way":
            $ wrong_questions.append("Q2")
        "In education, AI can act as an intelligent tutor through computer-assisted instruction (CAI) systems that adapt to students’ needs and provide personalized feedback":
            $ score += 1
        "AI completely eliminates the need for interaction between students and teachers":
            $ wrong_questions.append("Q2")
        "AI prioritizes administrative tasks over student learning":
            $ wrong_questions.append("Q2")

        


# Q4 (Correct = 1)
    
    mod2_friendB "Okay, just two more questions. How do autonomous vehicles use AI?"

    p "AI is used in autonomous vehicles..."

    menu:
        
        "Autonomous vehicles rely on pre-defined/programmed routes without adapting to road conditions":
            $ wrong_questions.append("Q2")
        "AI is being used in autonomous vehicles, where self-driving systems rely on sensors, cameras, and machine learning to understand their surroundings and make real-time driving decisions":
            $ score += 1
        "AI eliminates the need for traffic and environmental signals in autonomous vehicles":
            $ wrong_questions.append("Q2")
        "AI only allows autonomous vehicles to be in controlled environments with no variability":
            $ wrong_questions.append("Q2")

        
    

# Q5 (Correct = 1)
  
    mod2_friendB "Last question, are you ready?"

    p "Ask away!"

    mod2_friendB "What role does AI play in cybersecurity?"
    p "For cybersecurity AI..."

    menu:
        
        "In cybersecurity, AI physically intercepts hackers by manifesting as a digital wall that blocks their keyboard signals.":
            $ wrong_questions.append("Q2")
        "In cybersecurity, AI helps detect suspicious behavior, identify threats, and respond to attacks more quickly.":
            $ score += 1
        "In cybersecurity, AI creates 'digital ghosts' of deleted files to haunt potential intruders and scare them off the network.":
            $ wrong_questions.append("Q2")
        "4.	In cybersecurity, AI is primarily used to create a virus that attacks persistent hackers":
            $ wrong_questions.append("Q2")

        
        


# Q6 (Correct = 1)
  


# Q7 (Correct = 1)
    

  
       


# -------------------------------------------------
# RESULTS
# -------------------------------------------------

    if score == 2:
        jump module2_pass
    else:
        jump module2_fail



# -------------------------------------------------
# PASS ENDING
# -------------------------------------------------

label module2_pass:

    mod2_friendB "Impressive."

    mod2_friendB "You clearly understand how AI is used across industries."

    mod2_friendB "I’d like to offer you the internship."

    p "Really?! Thank you!"

    mod2_friendB "We’ll be in touch soon."

    $ module2_complete = True

    centered "Module 2 Complete"
    centered "Module 3 Unlocked"

    jump hub



# -------------------------------------------------
# FAIL ENDING
# -------------------------------------------------

label module2_fail:

    mod2_friendB "You have potential, but I think you need a stronger understanding."

    mod2_friendB "I recommend reviewing the material and trying again."

    centered "You answered some questions incorrectly."

    "Incorrect Questions: [', '.join(wrong_questions)]"

    menu:
        "Retry":
            jump module2_quiz

        "Return to Menu":
            jump hub

