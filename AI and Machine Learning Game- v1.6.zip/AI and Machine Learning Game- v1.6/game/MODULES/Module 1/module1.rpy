# Intro
label module1_intro:

    call screen module1_intro

label module1_start:

    call screen module1_start

    menu:
        "Continue to simulation":
            jump module1_simulation

#Simulation
label module1_simulation:

    p "Hey Ryan, how are you doing?"
    mod1_friendA "Hey [p], you never texted back yesterday!"
    p "Yeah, sorry I was busy studying for our quiz that’s unfortunately in thirty minutes."
    mod1_friendA "What quiz is in thirty minutes?"
    p "Remember how Dr. Cornell was teaching about the basic history of artificial intelligence, aka AI, last class? The quiz is going to be on the stuff she covered."
    mod1_friendA "Actually, I don’t remember anything about AI or a quiz. I pulled an all nighter the day before, so I was literally falling asleep during that class."
    p "No way. How are you going to pass the quiz?"
    mod1_friendA "By asking my amazing friend who spent all day yesterday studying to tell me what I need to know."
    mod1_friendA "Please help me, my grade is already bad as it is"
    p "Well lucky for you, during class she told us some of the questions that are going to be on the test and I wrote them down. If you can get them right, you’ll at least pass since there aren’t that many questions."
    mod1_friendA "Do you mind if I look at the questions you wrote down?"
    p "Of course not, go for it."

    "Ryan takes a couple minutes to scan through the questions in your notebook."


    menu:

        "Player choice 1":
            jump m1_good

        "Player choice 2":
            jump m1_basic

        "IPlayer choice 3":
            jump m1_unsure