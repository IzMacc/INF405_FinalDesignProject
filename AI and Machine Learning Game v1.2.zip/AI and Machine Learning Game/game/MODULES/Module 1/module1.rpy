﻿# Intro
label module1_intro:

    call screen module1_intro

    "Welcome to Module 1."

    "This module introduces the foundations of artificial intelligence."
   
# Draft
    "----Placeholder text----"


menu:
    "Continue to simulation":
        jump module1_simulation


#Simulation
label module1_simulation:

    npc "STUDENT_A"

    menu:

        "Player choice 1":
            jump m1_good

        "Player choice 2":
            jump m1_basic

        "IPlayer choice 3":
            jump m1_unsure