﻿define p = Character("[player_name]")
define npc = Character("Dr. Rivera")