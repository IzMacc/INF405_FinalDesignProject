# Intro
label module2_intro:

    call screen module2_intro

label module2_start:

    call screen module2_start

    menu module2_continue_menu:
        "Continue to simulation":
            jump module2_simulation


# -------------------------------------------------
# SIMULATION (Career Fair Scene)
# -------------------------------------------------

label module2_simulation:

    scene bg careerfair

    "After learning about AI in Dr. Cornell’s class, you begin researching it in your free time."

    "Eventually, your university hosts a career fair for tech internships."

    "You walk around until you find a booth labeled GRIN."

    p "Hello, my name is [player_name]."

    p "I’m really interested in AI, and I’d love to learn more about your company."

    show mod2_friendB normal at right

    mod2_friendB "Of course! My name is mod2_friendB."

    mod2_friendB "GRIN stands for Governance, Resilience, Integration, and Networking."

    mod2_friendB "These pillars guide how we work with AI systems."

    mod2_friendB "Do you have any experience with AI?"

    p "I’ve learned about it in class and done some research on my own."

    mod2_friendB "So no hands-on experience yet?"

    "You look down, slightly nervous."

    p "Not yet, but I’m eager to learn and gain experience."

    mod2_friendB "You remind me of myself when I started."

    mod2_friendB "We’re offering entry-level internships."

    mod2_friendB "But first, I’d like to ask you a few questions."

    mod2_friendB "I won’t tell you if you’re correct."

    mod2_friendB "Sound fair?"

    p "Yes! Thank you for the opportunity."

    jump module2_quiz



# -------------------------------------------------
# QUIZ (7 QUESTIONS)
# -------------------------------------------------

label module2_quiz:

    $ score = 0
    $ wrong_questions = []


# Q1 (Correct = 1)
    mod2_friendB "First question: How is AI commonly used in healthcare?"

    menu:
        "AI is used for diagnosis, medical imaging, and improving patient care":
            $ score += 1
        "AI replaces doctors completely":
            $ wrong_questions.append("Q1")
        "AI guarantees perfect predictions":
            $ wrong_questions.append("Q1")
        "AI gives instructions to patients":
            $ wrong_questions.append("Q1")


# Q2 (Correct = 1)
    mod2_friendB "Next: What is one way AI helps businesses?"

    menu:
        "Customer service, inventory management, and predicting demand":
            $ score += 1
        "It removes all employees":
            $ wrong_questions.append("Q2")
        "It guarantees profit":
            $ wrong_questions.append("Q2")
        "It replaces decision making entirely":
            $ wrong_questions.append("Q2")


# Q3 (Correct = 1)
    
        


# Q4 (Correct = 1)
    

    

# Q5 (Correct = 1)
  

        


# Q6 (Correct = 1)
  


# Q7 (Correct = 1)
    

  
       


# -------------------------------------------------
# RESULTS
# -------------------------------------------------

    if score == 2:
        jump module2_pass
    else:
        jump module2_fail



# -------------------------------------------------
# PASS ENDING
# -------------------------------------------------

label module2_pass:

    mod2_friendB "Impressive."

    mod2_friendB "You clearly understand how AI is used across industries."

    mod2_friendB "I’d like to offer you the internship."

    p "Really?! Thank you!"

    mod2_friendB "We’ll be in touch soon."

    $ module2_complete = True

    centered "Module 2 Complete"
    centered "Module 3 Unlocked"

    jump hub



# -------------------------------------------------
# FAIL ENDING
# -------------------------------------------------

label module2_fail:

    mod2_friendB "You have potential, but I think you need a stronger understanding."

    mod2_friendB "I recommend reviewing the material and trying again."

    centered "You answered some questions incorrectly."

    "Incorrect Questions: [', '.join(wrong_questions)]"

    menu:
        "Retry":
            jump module2_quiz

        "Return to Menu":
            jump hub

