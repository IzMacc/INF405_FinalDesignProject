# Intro
label module2_intro:

    call screen module2_intro

label module2_start:

    call screen module2_start

    menu module2_continue_menu:
        "Continue to simulation":
            jump module2_simulation

#Simulation
label module2_simulation:

    #mod1_friendA "Hey [p]!"

    #p "Hi [mod1_friendA], are you ready for the AI quiz next class?"
    #mod1_friendA "What quiz!?"

    menu module2_choices:

        "Player choice 1":
            jump m2_good

        "Player choice 2":
            jump m2_basic

        "IPlayer choice 3":
            jump m2_unsure

