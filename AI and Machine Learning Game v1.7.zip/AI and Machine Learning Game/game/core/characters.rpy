﻿define p = Character("player_name", dynamic=True)
define mod1_friendA = "Ryan"