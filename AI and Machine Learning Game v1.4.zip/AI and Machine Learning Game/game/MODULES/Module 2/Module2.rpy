﻿label module2_lesson:

    scene black

    "Welcome to Module 2."

    jump module2_finished


label module2_finished:

    $ module2_complete = True

    "You completed Module 2."

    jump start