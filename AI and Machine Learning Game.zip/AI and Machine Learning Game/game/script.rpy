﻿# The script of the game goes in this file.

# Declare characters used by this game. The color argument colorizes the
# name of the character.

# The game starts here.

label start:

    scene black

    # This name can be changed, its a temp right now
    "Welcome to the AI Learning Program."

    $ player_name = renpy.input("What would you like your name to be?")

    $ player_name = player_name.strip()

    if player_name == "":
        $ player_name = "Player"

    "Nice to meet you, [player_name]."

    call screen module_map

    return