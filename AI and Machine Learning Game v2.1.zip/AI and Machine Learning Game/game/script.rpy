# The script of the game goes in this file.



# The game starts here.

label start:

    scene black

    # This name can be changed, its a temp right now
    "Welcome to the AI Learning Program."

    $ player_name = renpy.input("What would you like your name to be? This is the name you will keep for the rest of the game.")
    $ player_name = player_name.strip()




    if player_name == "":
        $ player_name = "Player"

    "Nice to meet you, [player_name]."
    jump module_select

label module_select:
    call screen module_map

    return


# =================
# images
# =================

#MODULE 1 IMAGES

image bg restaurant = "images/burger_restaurant.png"
image bg restaurant = im.Scale("images/burger_restaurant.png", 1920, 1080)

image ryan normal = "images/ryan_normal.png"
image player normal = "images/player_normal.png"
image ryan normal = im.Scale("images/ryan_normal.png", 700, 1100)
image player normal = im.Scale("images/player_normal.png", 700, 1100)

# Module 2 Images

image bg careerfair = "images/career_fair.jpg"
image bg careerfair = im.Scale("images/career_fair.jpg", 1920, 1080)