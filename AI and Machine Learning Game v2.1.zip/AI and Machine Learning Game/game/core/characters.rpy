﻿define p = Character("player_name", dynamic=True)
define mod1_friendA = "Ryan"
define mod2_friendB = "Jasmine"
define mod3_friendC = "Mr. Brown"
define mod4_brother = "Jake"