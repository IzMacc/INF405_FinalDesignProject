﻿# -------------------------------------------------
# MODULE 3 : Machine Learning & Deep Learning
# -------------------------------------------------


# -------------------------------------------------
# INTRO + LESSON SCREEN
# -------------------------------------------------

label module3_intro:

    call screen module3_intro
    return


label module3_start:

    call screen module3_start

    menu:
        "Continue to simulation":
            jump module3_simulation



# -------------------------------------------------
# SIMULATION (Internship Meeting Scene)
# -------------------------------------------------

label module3_simulation:

    scene bg office


    "It is your first day at GRIN."

    mod3_friendC "Good morning, [player_name]. Congratulations on your internship."

    mod3_friendC "How is your first day going?"

    p "Great! I brushed up on AI and machine learning basics."

    mod3_friendC "Good. At GRIN, we expect interns to understand how and when to use AI."

    mod3_friendC "Let’s start with some questions."

    jump module3_quiz



# -------------------------------------------------
# QUIZ 
# -------------------------------------------------

label module3_quiz:

    $ score = 0
    $ wrong_questions = []


# -------------------------------------------------
# QUESTION 1
# Correct = 3
# -------------------------------------------------

    mod3_friendC "What is the relationship between AI and machine learning?"

    menu:

        "Artificial intelligence is a subset of machine learning":
            $ wrong_questions.append("Question 1")

        "Machine learning is the overall field of using computers to mimic human intelligence, artificial intelligence makes this possible":
            $ wrong_questions.append("Question 1")

        "Machine learning is a subset of Artificial Intelligence":
            $ score += 1

        "Machine learning is unrelated to Artificial Intelligence":
            $ wrong_questions.append("Question 1")



# -------------------------------------------------
# QUESTION 2
# Correct = 1
# -------------------------------------------------

    mod3_friendC "What is the main goal of machine learning?"

    menu:

        "To learn patterns from existing data and make inferences on new data":
            $ score += 1

        "To store relevant data and automatically remove irrelevant data":
            $ wrong_questions.append("Question 2")

        "To set rules for new data":
            $ wrong_questions.append("Question 2")

        "To design computer hardware":
            $ wrong_questions.append("Question 2")



# -------------------------------------------------
# QUESTION 3
# Correct = 2
# -------------------------------------------------

    mod3_friendC "What type of data is used in supervised learning?"

    menu:

        "Unlabeled and unstructured data":
            $ wrong_questions.append("Question 3")

        "Labeled and structured data":
            $ score += 1

        "Numerical data":
            $ wrong_questions.append("Question 3")

        "Random datasets":
            $ wrong_questions.append("Question 3")



# -------------------------------------------------
# QUESTION 4
# Correct = 4
# -------------------------------------------------

    mod3_friendC "What is the main idea behind reinforced learning?"

    menu:

        "Reinforced data groups data into unstructured clusters":
            $ wrong_questions.append("Question 4")

        "Reinforced learning groups data based similar words":
            $ wrong_questions.append("Question 4")

        "Reinforced learning learns from unlabeled data":
            $ wrong_questions.append("Question 4")

        "Reinforced learning uses nested equations to map inputs to outputs":
            $ score += 1



# -------------------------------------------------
# QUESTION 5
# Correct = 1
# -------------------------------------------------

    mod3_friendC "What is deep learning?"

    menu:

        "Deep learning (DL) is a subset of machine learning that involves multilayered neural networks that are modeled after the structure of the human brain":
            $ score += 1

        "Deep learning (DL) is the new version of machine learning with increased capabilities":
            $ wrong_questions.append("Question 5")

        "Deep learning (DL) is a special type of artificial intelligence that is responsible for natural language processing and convolutional neural networks":
            $ wrong_questions.append("Question 5")

        "Deep learning (DL) is a term used when thinking critically about ways to implement AI":
            $ wrong_questions.append("Question 5")



# -------------------------------------------------
# RESULTS
# -------------------------------------------------

    if score == 5:
        jump module3_pass

    else:
        jump module3_fail


# -------------------------------------------------
# PASS
# -------------------------------------------------

label module3_pass:

    mod3_friendC "Great job, [player_name]."

    mod3_friendC "You clearly understand machine learning concepts."

    mod3_friendC "I’ll keep you in mind for future projects."

    $ module3_complete = True

    centered "Module 3 Complete"
    centered "Module 4 Unlocked"

    jump module_select



# -------------------------------------------------
# FAIL
# -------------------------------------------------

label module3_fail:

    mod3_friendC "Those answers weren’t quite correct."

    mod3_friendC "I recommend reviewing machine learning fundamentals."

    centered "Incorrect Questions: [', '.join(wrong_questions)]"

    menu:
        "Retry Quiz":
            jump module3_quiz

        "Return to Menu":
            jump module_select
