# Intro
label module1_intro:

    call screen module1_intro

label module1_start:

    call screen module1_start

    menu:
        "Continue to simulation":
            jump module1_simulation

#Simulation
label module1_simulation:

    scene bg restaurant

    show player normal at right
    show ryan normal at left

    "You are walking into a burger restaurant close to campus when you spot your close friend Ryan sitting down."

    p "Hey Ryan, how are you doing?"

    mod1_friendA "Hey [player_name], you never texted back yesterday!"

    p "Yeah, sorry I was busy studying for our quiz that's unfortunately in thirty minutes."

    mod1_friendA "What quiz is in thirty minutes?"

    p "Remember how Dr. Cornell was teaching about the basic history of artificial intelligence, aka AI, last class?"

    p "The quiz is going to be on the stuff she covered."

    mod1_friendA "Actually, I don't remember anything about AI or a quiz."

    mod1_friendA "I pulled an all nighter the day before, so I was literally falling asleep during that class."

    p "No way. How are you going to pass the quiz?"

    mod1_friendA "By asking my amazing friend who spent all day yesterday studying to tell me what I need to know."

    mod1_friendA "Please help me, my grade is already bad as it is."

    p "Well lucky for you, during class she told us some of the questions that are going to be on the test and I wrote them down."

    p "If you can get them right, you'll at least pass since there aren't that many questions."

    mod1_friendA "Do you mind if I look at the questions you wrote down?"

    p "Of course not, go for it."

    "Ryan takes a couple minutes to scan through the questions in your notebook."

    jump module1_quiz



# -------------------------------------------------
# QUIZ SECTION
# Must get all 5 correct
# -------------------------------------------------

label module1_quiz:

    $ score = 0
    $ wrong_questions = []



# -------------------------------------------------
# QUESTION 1
# Correct = Choice 4
# -------------------------------------------------

    mod1_friendA "Okay so question one is: What is artificial intelligence?"

    p "Artificial intelligence is..."

    menu:

        "A sentient digital consciousness with emotions and desires.":
            $ wrong_questions.append("Question 1")

        "A supernatural system that predicts the future.":
            $ wrong_questions.append("Question 1")

        "A field replacing computer science entirely.":
            $ wrong_questions.append("Question 1")

        "A category of computer science focused on creating intelligent systems that replicate human critical thinking capabilities.":
            $ score += 1

    mod1_friendA "That sounds kind of complicated, but I'm gonna go with it."



# -------------------------------------------------
# QUESTION 2
# Correct = Choice 2
# -------------------------------------------------

    mod1_friendA "Alright next question is, who coined the term artificial intelligence?"

    p "The term was coined by..."

    menu:

        "Gary Kasparov":
            $ wrong_questions.append("Question 2")

        "John McCarthy":
            $ score += 1

        "Makoto Nishimura":
            $ wrong_questions.append("Question 2")

        "Edward Feigenbaum":
            $ wrong_questions.append("Question 2")

    mod1_friendA "I'm going to try my hardest to remember that."



# -------------------------------------------------
# QUESTION 3
# Correct = Choice 1
# -------------------------------------------------

    mod1_friendA "The next question says, why is the term artificial intelligence considered difficult to define?"

    mod1_friendA "This question doesn't even make sense. Didn't you just explain what AI is?"

    p "Even though I explained what AI is, it's still difficult to define because..."

    menu:

        "AI is constantly evolving and can be perceived differently depending on the context.":
            $ score += 1

        "The public refuses to define it.":
            $ wrong_questions.append("Question 3")

        "Patent laws have not decided yet.":
            $ wrong_questions.append("Question 3")

        "The Dartmouth Agreement strictly limited the definition.":
            $ wrong_questions.append("Question 3")

    mod1_friendA "I guess that makes sense."



# -------------------------------------------------
# QUESTION 4
# Correct = Choice 2
# -------------------------------------------------

    mod1_friendA "Moving forward, what was the AI Winter? Ouu that sounds kind of cool."

    p "The AI Winter was..."

    menu:

        "A programming error caused by cold code.":
            $ wrong_questions.append("Question 4")

        "A period of low interest in AI that caused decreased funding, resulting in fewer advancements.":
            $ score += 1

        "A future blackout caused by AI.":
            $ wrong_questions.append("Question 4")

        "Proof computers can never learn.":
            $ wrong_questions.append("Question 4")



# -------------------------------------------------
# QUESTION 5
# Correct = Choice 2
# -------------------------------------------------

    mod1_friendA "Okay last question, what was special about IBM's Deep Blue in 1997?"

    p "What made it special was..."

    menu:

        "It used synthetic neurons.":
            $ wrong_questions.append("Question 5")

        "It was designed to play chess and defeated the world champion at the time.":
            $ score += 1

        "It defeated the world champion in Go.":
            $ wrong_questions.append("Question 5")

        "It used quantum computing.":
            $ wrong_questions.append("Question 5")



# -------------------------------------------------
# QUIZ RESULTS
# -------------------------------------------------

    mod1_friendA "Well that's all of them."

    mod1_friendA "We should leave soon if we're going to make it to class on time."

    mod1_friendA "I think I remember everything you said."

    mod1_friendA "If I don't pass, I'll have you to blame!"

    p "You'll do fine, don't worry."

    "Ryan and [player_name] leave the restaurant and begin walking to class."

    "Time passes..."

    if score == 5:
        jump module1_pass
    else:
        jump module1_fail



# -------------------------------------------------
# PASS ENDING
# -------------------------------------------------

label module1_pass:

    "The next day Ryan calls you."

    p "Hey Ryan, what's up?"

    mod1_friendA "You're literally a lifesaver!"

    mod1_friendA "I passed the quiz because of those questions you helped me with."

    p "I told you not to worry!"

    mod1_friendA "I'm so glad you were right."

    mod1_friendA "Your next burger is on me."

    $ module1_complete = True

    scene black

    centered "Module 1 Complete"

    centered "Module 2 Unlocked"

    jump module_select



# -------------------------------------------------
# FAIL ENDING
# -------------------------------------------------

label module1_fail:

    "The next day Ryan calls you."

    p "Hey Ryan, what's up?"

    mod1_friendA "Did you really spend all day studying for that quiz?"

    mod1_friendA "I literally failed."

    mod1_friendA "Next time, I'll just ask Sarah."

    "Ryan hangs up, clearly upset."

    scene black

    centered "You answered some questions incorrectly."

    "Incorrect Questions: [', '.join(wrong_questions)]"

    menu:

        "Retry Quiz":
            jump module1_quiz

        "Return to Menu":
            jump module_select
            return